export interface AiConversation {
  id: string;
  title: string;
  created_at: string;
  updated_at: string;
}
export interface ChatInput {
  conversation_id: string;
  request_id: string;
  content: string;
  mode: 'STUDY' | 'ACADEMIC';
  course_code: string | null;
  include_academic_context: boolean;
  include_moodle_context: boolean;
  allow_external_context: boolean;
}
export interface AiMessage {
  id: string;
  role: 'USER' | 'ASSISTANT';
  content: string;
  origin: 'STUDENT' | 'GEMINI' | 'DETERMINISTIC';
  context_scope: string;
  created_at: string;
  request_id: string;
  request_status: 'RUNNING' | 'COMPLETED' | 'FAILED';
  error_code: string | null;
  metadata: { input?: ChatInput; truncated?: boolean; model?: string; context_sources?: string[] };
}
export interface AiDetail {
  id: string;
  title: string;
  messages: AiMessage[];
}
export interface AiUsage {
  configured: boolean;
  model: string;
  daily_limit: number;
  used_today: number;
  remaining_today: number;
  max_input_characters: number;
  max_output_tokens: number;
  retention_days: number;
  quota_timezone: string;
  academic_rules_available: boolean;
}
export interface MoodleStatus {
  monitoring_opt_in?: boolean;
  notification_categories?: string[];
  browser_connection?: { available: boolean; reason: string };
  state:
    | 'NOT_CONFIGURED'
    | 'CONFIGURED'
    | 'CONNECTED'
    | 'AUTHENTICATION_FAILED'
    | 'PERMISSION_DENIED'
    | 'SYNC_ERROR';
  institution_url: string | null;
  can_sync: boolean;
  automatic_sync: boolean;
  sync_interval_minutes: number;
  notifications_enabled: boolean;
  capabilities: string[];
  last_attempt_at: string | null;
  last_success_at: string | null;
  error_code: string | null;
  revision: number | null;
}
export interface MoodleCourse {
  external_id: string;
  name: string;
  shortname: string;
  source_url: string | null;
}
export interface MoodleItem {
  id: string;
  external_id: string;
  kind: 'ASSIGNMENT' | 'QUIZ' | 'ANNOUNCEMENT' | 'CALENDAR' | 'MATERIAL';
  title: string;
  description: string;
  due_at: string | null;
  published_at: string | null;
  source_url: string | null;
  metadata: Record<string, unknown>;
  last_seen_at: string;
  course_name: string;
  source: 'MOODLE';
}
export interface SyncRun {
  id: string;
  status: string;
  started_at: string;
  finished_at: string | null;
  error_code: string | null;
  trigger_type: string;
  summary: Record<string, unknown>;
}
