import { Link } from 'react-router-dom';
import { ErrorState, Skeleton } from '../components/ui';
import { BadgeGallery } from './Achievements';
import { StudentAvatar } from './Avatar';
import { useEngagement } from './hooks';
import { NewsTicker } from './NewsTicker';
import { StreakCard } from './Streak';
import { Achievement, Streak } from './types';

export function EngagementDashboard() {
  const streak = useEngagement<Streak>('/streaks'),
    badges = useEngagement<Achievement[]>('/achievements');
  return (
    <>
      <div className="eng-dashboard">
        <div>
          {streak.error ? (
            <ErrorState error={streak.error} retry={() => void streak.refetch()} />
          ) : streak.isPending ? (
            <Skeleton />
          ) : (
            <StreakCard value={streak.data} />
          )}
        </div>
        <section className="surface">
          <div className="section-heading">
            <div className="eng-person">
              <StudentAvatar size={64} />
              <h2>مجموعة إنجازاتك</h2>
            </div>
            <Link to="/app/achievements">كل الشارات</Link>
          </div>
          {badges.error ? (
            <ErrorState error={badges.error} retry={() => void badges.refetch()} />
          ) : badges.isPending ? (
            <Skeleton />
          ) : (
            <BadgeGallery items={badges.data} compact />
          )}
          <Link className="helper" to="/app/avatar">
            تخصيص الأفاتار
          </Link>
        </section>
      </div>
      <NewsTicker />
    </>
  );
}
