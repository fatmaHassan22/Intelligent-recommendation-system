import { useMutation } from '@tanstack/react-query';
import { useState } from 'react';
import { api, errorMessage } from '../api/client';
import {
  Button,
  ErrorState,
  Input,
  PageHeader,
  Select,
  Skeleton,
  useToast,
} from '../components/ui';
import { initialAvatar } from './constants';
import { prefix, useEngagement, useRefresh } from './hooks';
import { Avatar } from './types';

export function AvatarSvg({ value = initialAvatar, size = 48 }: { value?: Avatar; size?: number }) {
  const { style, color, background, eyes, accessory } = value;
  return (
    <svg
      className="eng-avatar"
      width={size}
      height={size}
      viewBox="0 0 100 100"
      role="img"
      aria-label={`أفاتار ${style === 'CAT' ? 'قطة' : style === 'ROBOT' ? 'روبوت' : 'طالب'}`}
    >
      <rect width="100" height="100" rx="28" fill={background} />
      {style === 'CAT' && <path d="M20 38L20 15L42 31M58 31L80 15L80 38" fill={color} />}{' '}
      {style === 'ROBOT' && (
        <>
          <path d="M50 18V9" stroke={color} strokeWidth="5" />
          <circle cx="50" cy="8" r="5" fill={color} />
        </>
      )}
      <rect x="18" y="27" width="64" height="55" rx={style === 'ROBOT' ? 13 : 30} fill={color} />
      {style === 'STUDENT' && (
        <path d="M20 43Q20 20 50 24Q78 20 80 43L65 30L50 38L35 30Z" fill="#173D4D" />
      )}
      {eyes === 'HAPPY' ? (
        <path
          d="M31 51Q36 43 41 51M59 51Q64 43 69 51"
          stroke="#163744"
          strokeWidth="4"
          fill="none"
          strokeLinecap="round"
        />
      ) : (
        <>
          <circle cx="36" cy="49" r="4" fill="#163744" />
          <circle cx="64" cy="49" r="4" fill="#163744" />
        </>
      )}
      <path
        d="M39 64Q50 75 61 64"
        stroke="#163744"
        strokeWidth="4"
        fill="none"
        strokeLinecap="round"
      />
      {accessory === 'GLASSES' && (
        <g fill="none" stroke="#123641" strokeWidth="3">
          <rect x="25" y="41" width="23" height="17" rx="5" />
          <rect x="52" y="41" width="23" height="17" rx="5" />
          <path d="M48 47H52" />
        </g>
      )}
      {accessory === 'CAP' && (
        <>
          <path d="M17 28L50 15L84 28L50 40Z" fill="#173D4D" />
          <path d="M78 29V43" stroke="#D5B868" strokeWidth="3" />
        </>
      )}
    </svg>
  );
}
export function StudentAvatar({ size = 44 }: { size?: number }) {
  const q = useEngagement<Avatar>('/avatar');
  return <AvatarSvg size={size} value={q.data} />;
}
export function AvatarEditor({ value }: { value: Avatar }) {
  const [draft, setDraft] = useState(value),
    refresh = useRefresh(),
    toast = useToast();
  const save = useMutation({
    mutationFn: () => api.mutate(prefix + '/avatar', 'PATCH', draft),
    onSuccess: async () => {
      await refresh();
      toast('حُفظ أفاتارك.');
    },
    onError: (e) => toast(errorMessage(e), 'error'),
  });
  return (
    <section className="surface avatar-editor">
      <div className="avatar-preview">
        <AvatarSvg value={draft} size={150} />
        <h2>هذه معاينتك</h2>
        <small>تظهر التغييرات في حسابك بعد الحفظ.</small>
      </div>
      <form
        onSubmit={(e) => {
          e.preventDefault();
          save.mutate();
        }}
      >
        <div className="form-two">
          <Select
            label="أسلوب الأفاتار"
            value={draft.style}
            onChange={(e) => setDraft({ ...draft, style: e.target.value as Avatar['style'] })}
          >
            <option value="STUDENT">طالب</option>
            <option value="CAT">قطة</option>
            <option value="ROBOT">روبوت</option>
          </Select>
          <Select
            label="العينان"
            value={draft.eyes}
            onChange={(e) => setDraft({ ...draft, eyes: e.target.value as Avatar['eyes'] })}
          >
            <option value="ROUND">هادئتان</option>
            <option value="HAPPY">مبتسمتان</option>
          </Select>
          <Input
            label="لون الأفاتار"
            type="color"
            value={draft.color}
            onChange={(e) => setDraft({ ...draft, color: e.target.value })}
          />
          <Input
            label="لون الخلفية"
            type="color"
            value={draft.background}
            onChange={(e) => setDraft({ ...draft, background: e.target.value })}
          />
          <Select
            label="الإضافة"
            value={draft.accessory}
            onChange={(e) =>
              setDraft({
                ...draft,
                accessory: e.target.value as Avatar['accessory'],
              })
            }
          >
            <option value="NONE">دون إضافة</option>
            <option value="GLASSES">نظارات</option>
            <option value="CAP">قبعة تخرج</option>
          </Select>
        </div>
        <div className="dialog-actions">
          <Button type="button" variant="secondary" onClick={() => setDraft({ ...initialAvatar })}>
            إعادة المعاينة للافتراضي
          </Button>
          <Button type="submit" busy={save.isPending}>
            حفظ الأفاتار
          </Button>
        </div>
        {save.error && (
          <p role="alert" className="form-error">
            {errorMessage(save.error)}
          </p>
        )}
      </form>
    </section>
  );
}
export function AvatarPage() {
  const q = useEngagement<Avatar>('/avatar');
  return (
    <>
      <PageHeader
        eyebrow="شخصية تشبه أسلوبك"
        title="الأفاتار"
        description="اختاري الشكل والألوان، وعايني النتيجة قبل حفظها."
      />
      {q.error ? (
        <ErrorState error={q.error} retry={() => void q.refetch()} />
      ) : q.isPending ? (
        <Skeleton />
      ) : (
        <AvatarEditor key={JSON.stringify(q.data)} value={q.data} />
      )}
    </>
  );
}
