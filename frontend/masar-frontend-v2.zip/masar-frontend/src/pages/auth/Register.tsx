import { useMutation } from '@tanstack/react-query';
import { ArrowLeft, Check } from 'lucide-react';
import { CSSProperties, ReactNode, useEffect, useRef, useState, type FormEvent } from 'react';
import { Navigate, useNavigate } from 'react-router-dom';
import { api, errorMessage } from '../../api/client';
import type { Registration, StudyMode, User } from '../../api/types';
import { Button, ErrorState, Input, modeLabel, Select } from '../../components/ui';
import { useMajors, usePlans } from '../../hooks';
import { useAuth } from '../../state';

import { AuthFrame, SwitchLink } from './AuthFrame';

export const titles = [
  'معلوماتك الشخصية',
  'بياناتك الأكاديمية',
  'تفضيلات الدراسة',
  'مراجعة بياناتك',
];
export const initial: Registration = {
  full_name: '',
  email: '',
  password: '',
  major_id: '',
  curriculum_plan_id: '',
  university_student_number: null,
  max_semester_credit_hours: 18,
  preferred_study_mode: 'BALANCED',
  career_interest: null,
};
export function validateStep(step: number, data: Registration): string | null {
  if (step === 0) {
    if (!data.full_name.trim()) return 'أدخلي اسمك الكامل.';
    if (!/^[\x21-\x7e]+@[^\s@]+\.[^\s@]+$/.test(data.email.trim()))
      return 'أدخلي بريدًا إلكترونيًا صالحًا.';
    if (data.password.length < 12 || new TextEncoder().encode(data.password).length > 72)
      return 'كلمة المرور يجب أن تكون 12 حرفًا على الأقل وألا تتجاوز 72 بايت.';
  }
  if (step === 1 && (!data.major_id || !data.curriculum_plan_id))
    return 'اختاري تخصصًا وخطة من القائمة.';

  if (
    step === 2 &&
    (!Number.isInteger(data.max_semester_credit_hours) ||
      data.max_semester_credit_hours <= 0 ||
      data.max_semester_credit_hours > 65535)
  )
    return 'أدخلي عدد ساعات صحيحًا موجبًا.';
  return null;
}
export function Stepper({ steps, current }: { steps: string[]; current: number }) {
  const n = steps.length,
    p = n > 1 ? current / (n - 1) : 0;
  return (
    <ol
      aria-label="خطوات إنشاء الحساب"
      style={{ '--n': n, '--p': p } as CSSProperties}
      className="relative mb-8 grid animate-rise auto-cols-fr grid-flow-col [animation-delay:.2s]"
    >
      <span
        aria-hidden="true"
        className="absolute top-[15px] h-[3px] rounded bg-[#e8eef4] [inset-inline-start:calc(100%/var(--n)/2)] [width:calc(100%_-_100%/var(--n))]"
      />
      <span
        aria-hidden="true"
        className="absolute top-[15px] h-[3px] rounded bg-accent transition-[width] duration-700 ease-out [inset-inline-start:calc(100%/var(--n)/2)] [width:calc((100%_-_100%/var(--n))*var(--p))]"
      />
      {steps.map((label, i) => {
        const state = i < current ? 'done' : i === current ? 'active' : 'todo';
        return (
          <li
            key={label}
            aria-current={i === current ? 'step' : undefined}
            className="relative z-10 flex flex-col items-center gap-2 text-center"
          >
            <span
              className={`grid size-8 place-items-center rounded-full text-[13px] font-bold shadow-[0_0_0_4px_#fff] transition-all duration-500 ${
                state === 'todo' ? 'bg-[#eef3f7] text-[#8a99ab]' : 'bg-accent text-white'
              } ${state === 'active' ? 'scale-110 animate-ring-pulse' : ''}`}
            >
              {state === 'done' ? <Check size={16} className="animate-pop" /> : i + 1}
            </span>
            <small
              className={`hidden max-w-[90px] text-xs transition-colors sm:block ${
                state === 'active'
                  ? 'font-semibold text-ink'
                  : state === 'done'
                    ? 'text-accent'
                    : 'text-[#8a99ab]'
              }`}
            >
              {label}
            </small>
          </li>
        );
      })}
    </ol>
  );
}
export function PasswordStrength({ value }: { value: string }) {
  const score = [
    value.length >= 12,
    /[a-z]/.test(value) && /[A-Z]/.test(value),
    /\d/.test(value),
    /[^A-Za-z0-9]/.test(value),
  ].filter(Boolean).length;
  const labels = ['ضعيفة', 'ضعيفة', 'مقبولة', 'جيدة', 'قوية'];
  const colors = ['', 'bg-[#e5534b]', 'bg-[#e6a23c]', 'bg-[#7bc67e]', 'bg-accent'];
  return (
    <div className="mt-2.5 flex min-h-[18px] items-center gap-3" aria-live="polite">
      <div className="grid flex-1 grid-cols-4 gap-1.5">
        {[1, 2, 3, 4].map((i) => (
          <span
            key={i}
            className={`h-[5px] rounded-full transition-all duration-500 ${i <= score ? `${colors[score]} scale-y-[1.3]` : 'bg-[#e8eef4]'}`}
          />
        ))}
      </div>
      <span className="min-w-12 text-xs font-semibold text-muted">
        {value ? labels[score] : ''}
      </span>
    </div>
  );
}
export function Register() {
  const auth = useAuth(),
    navigate = useNavigate(),
    majors = useMajors();

  const [step, setStep] = useState(0),
    [dir, setDir] = useState<'fwd' | 'back'>('fwd'),
    [data, setData] = useState<Registration>(initial),
    [error, setError] = useState<string | null>(null);

  const plans = usePlans(data.major_id);

  // نقل التركيز لعنوان الخطوة عند الانتقال فقط (وليس عند أول فتح للصفحة)
  const prevStep = useRef(step);
  useEffect(() => {
    if (prevStep.current !== step) {
      prevStep.current = step;
      document.querySelector<HTMLElement>('[data-step-title]')?.focus();
    }
  }, [step]);

  const set = <K extends keyof Registration>(key: K, value: Registration[K]) => {
    setData((d) => ({ ...d, [key]: value }));
    setError(null);
  };

  const register = useMutation({
    mutationFn: () =>
      api.mutate<{
        user: User;
        csrf_token: string;
      }>('/auth/register', 'POST', {
        ...data,
        full_name: data.full_name.trim(),
        email: data.email.trim(),
      }),
    onSuccess: (r) => {
      setData(initial);
      auth.accept(r.user);
      navigate('/app', { replace: true });
    },
  });

  if (auth.user) return <Navigate to="/app" replace />;

  const submit = (e: FormEvent) => {
    e.preventDefault();
    const invalid = validateStep(step, data);
    if (invalid) {
      setError(invalid);
      return;
    }
    if (step < 3) {
      setDir('fwd');
      setStep(step + 1);
      setError(null);
    } else register.mutate();
  };

  const message = error ?? (register.error ? errorMessage(register.error) : null);

  return (
    <AuthFrame title="ابدئي مسارك" subtitle="أربع خطوات قصيرة، وحساب يتبع خطتك أنتِ.">
      <Stepper steps={titles} current={step} />

      <form onSubmit={submit}>
        {/* key={step} يعيد تشغيل حركة الدخول عند كل خطوة */}
        <div
          key={step}
          className={`auth-stagger ${dir === 'back' ? 'animate-step-back' : 'animate-step-in'}`}
        >
          <h2 data-step-title tabIndex={-1} className="text-[19px] font-semibold outline-none">
            {titles[step]}
          </h2>

          {step === 0 && (
            <>
              <Input
                label="الاسم الكامل"
                autoComplete="name"
                required
                maxLength={255}
                value={data.full_name}
                onChange={(e) => set('full_name', e.target.value)}
              />
              <Input
                label="البريد الإلكتروني"
                type="email"
                dir="ltr"
                autoComplete="email"
                required
                maxLength={254}
                value={data.email}
                onChange={(e) => set('email', e.target.value)}
              />
              <Input
                label="كلمة المرور"
                type="password"
                autoComplete="new-password"
                required
                minLength={12}
                value={data.password}
                onChange={(e) => set('password', e.target.value)}
                hint="12 حرفًا على الأقل. لا تحفظ المنصة كلمة المرور بصيغتها الأصلية."
              />
              <PasswordStrength value={data.password} />
            </>
          )}

          {step === 1 && (
            <>
              {majors.error ? (
                <ErrorState error={majors.error} retry={() => void majors.refetch()} />
              ) : (
                <Select
                  label="التخصص"
                  required
                  value={data.major_id}
                  disabled={majors.isPending}
                  onChange={(e) =>
                    setData((d) => ({
                      ...d,
                      major_id: e.target.value,
                      curriculum_plan_id: '',
                    }))
                  }
                >
                  <option value="">
                    {majors.isPending ? 'جارٍ تحميل التخصصات…' : 'اختاري تخصصك'}
                  </option>
                  {majors.data?.map((m) => (
                    <option key={m.id} value={String(m.id)}>
                      {m.name_ar}
                    </option>
                  ))}
                </Select>
              )}
              <Select
                label="الخطة الدراسية"
                required
                disabled={!data.major_id || plans.isPending}
                value={data.curriculum_plan_id}
                onChange={(e) => set('curriculum_plan_id', e.target.value)}
              >
                <option value="">اختاري الخطة</option>
                {plans.data?.map((p) => (
                  <option key={p.id} value={String(p.id)}>
                    الخطة {p.plan_number}
                  </option>
                ))}
              </Select>
              {plans.error && <ErrorState error={plans.error} retry={() => void plans.refetch()} />}
              <Input
                label="الرقم الجامعي (اختياري)"
                maxLength={64}
                value={data.university_student_number ?? ''}
                onChange={(e) => set('university_student_number', e.target.value.trim() || null)}
              />
            </>
          )}

          {step === 2 && (
            <>
              <Input
                label="الحد الأقصى المفضل لساعات الفصل"
                type="number"
                min={1}
                max={65535}
                required
                value={data.max_semester_credit_hours || ''}
                onChange={(e) => set('max_semester_credit_hours', Number(e.target.value))}
                hint="تفضيل شخصي، وليس اعتمادًا للحد الأكاديمي المسموح."
              />
              <Select
                label="نمط الدراسة"
                value={data.preferred_study_mode}
                onChange={(e) => set('preferred_study_mode', e.target.value as StudyMode)}
              >
                <option value="LIGHT">خفيف</option>
                <option value="BALANCED">متوازن</option>
                <option value="FAST_GRADUATION">تخرج أسرع</option>
              </Select>
              <Input
                label="الاهتمام المهني (اختياري)"
                maxLength={255}
                value={data.career_interest ?? ''}
                onChange={(e) => set('career_interest', e.target.value.trim() || null)}
              />
              <p className="mt-3 text-xs leading-relaxed text-muted">
                نحتفظ بهذه التفضيلات. تُستخدم لتوصيات قائمة على قواعد واضحة، وليست قواعد تسجيل
                جامعية.
              </p>
            </>
          )}

          {step === 3 && (
            <>
              <dl className="mt-4 grid gap-2.5">
                {(
                  [
                    ['الاسم', data.full_name],
                    ['البريد', <span dir="ltr">{data.email}</span>],
                    ['التخصص', majors.data?.find((m) => String(m.id) === data.major_id)?.name_ar],
                    [
                      'الخطة',
                      plans.data?.find((p) => String(p.id) === data.curriculum_plan_id)
                        ?.plan_number,
                    ],
                    ['الرقم الجامعي', data.university_student_number ?? 'غير مدخل'],
                    ['الساعات المفضلة', data.max_semester_credit_hours],
                    ['نمط الدراسة', modeLabel(data.preferred_study_mode)],
                    ['الاهتمام المهني', data.career_interest ?? 'غير محدد'],
                  ] as [string, ReactNode][]
                ).map(([k, v]) => (
                  <div
                    key={k}
                    className="flex justify-between gap-4 rounded-[14px] border border-line bg-[#f9fbfd] px-4 py-3.5 text-sm"
                  >
                    <dt className="text-muted">{k}</dt>
                    <dd className="font-semibold">{v}</dd>
                  </div>
                ))}
              </dl>
              <p className="mt-3 text-xs leading-relaxed text-muted">
                راجعي بياناتك. يمكنك تعديل ملفك لاحقًا، مع تأكيد عند تغيير الخطة.
              </p>
            </>
          )}
        </div>

        {message && (
          <p
            key={message}
            role="alert"
            className="mt-4 animate-shake rounded-xl bg-[#fdecea] px-3.5 py-3 text-sm text-[#9a3412]"
          >
            {message}
          </p>
        )}

        <div className="flex flex-wrap gap-3">
          <Button type="submit" busy={register.isPending}>
            {step === 3 ? 'إنشاء حسابي' : 'التالي'}
            <ArrowLeft size={17} />
          </Button>
          {step > 0 && (
            <Button
              variant="secondary"
              type="button"
              disabled={register.isPending}
              onClick={() => {
                setDir('back');
                setStep(step - 1);
                setError(null);
              }}
            >
              السابق
            </Button>
          )}
        </div>
      </form>

      <SwitchLink text="لديكِ حساب؟" to="/login" label="تسجيل الدخول" />
    </AuthFrame>
  );
}
