import AIRecommendation from '../sections/AIRecommendation';
import CTA from '../sections/CTA';
import Faq from '../sections/Faq';
import Features from '../sections/Features';
import Footer from '../sections/Footer';
import Header from '../sections/Header';
import Hero from '../sections/Hero';
import HowItWorks from '../sections/HowItWorks';
import ProblemSolution from '../sections/ProblemSolution';
import TryIt from '../sections/TryIt';

export function Landing() {
  return (
    <>
      <Header />
      <main>
        <Hero />
        <ProblemSolution />
        <HowItWorks />
        <AIRecommendation />
        <Features />
        <TryIt />
        {/* <Assistant /> */}
        {/* <Tour /> */}
        {/* <Stories /> */}
        <Faq />
        <CTA />
      </main>
      <Footer />
    </>
  );
}
