import { ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';
import { Empty, PageHeader } from '../components/ui';

export function NotFoundPage() {
  return (
    <>
      <PageHeader title="الصفحة غير موجودة" description="الرابط الذي فتحته غير متاح في مساحتك." />
      <section className="surface">
        <Empty
          title="لا توجد صفحة بهذا العنوان"
          description="تحقق من الرابط أو عد إلى الصفحة الرئيسية."
          action={
            <Link className="btn btn-secondary" to="/app">
              <ArrowRight size={17} /> العودة للرئيسية
            </Link>
          }
        />
      </section>
    </>
  );
}
