import {
  ArrowLeft,
  BookOpen,
  CheckCheck,
  CheckCircle2,
  Compass,
  GraduationCap,
  Layers3,
  Plus,
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { Badge, Empty, ErrorState, PageHeader, Skeleton, Stat, number } from '../../components/ui';
import { EngagementDashboard } from '../../engagement';
import { useCompleted, useMajors, usePlans, useProfile, useProgress } from '../../hooks';
import { ProductivityDashboard } from '../../productivity/Tasks';
import { useAuth } from '../../state';

import { Completeness } from './components';

export function Dashboard() {
  const auth = useAuth(),
    profile = useProfile(),
    progress = useProgress(),
    completed = useCompleted(),
    majors = useMajors(),
    plans = usePlans(String(profile.data?.major_id ?? ''));
  if (profile.isPending || progress.isPending || completed.isPending) return <Skeleton />;
  if (profile.error || progress.error || completed.error || majors.error || plans.error)
    return (
      <ErrorState
        error={profile.error ?? progress.error ?? completed.error ?? majors.error ?? plans.error}
        retry={() => {
          void profile.refetch();
          void progress.refetch();
          void completed.refetch();
          void majors.refetch();
          void plans.refetch();
        }}
      />
    );
  const p = progress.data!,
    current = profile.data!,
    major = majors.data?.find((m) => String(m.id) === String(current.major_id)),
    plan = plans.data?.find((p) => String(p.id) === String(current.curriculum_plan_id));
  const recent = [...(completed.data ?? [])]
    .sort((a, b) => (b.created_at ?? '').localeCompare(a.created_at ?? ''))
    .slice(0, 3);
  return (
    <>
      <PageHeader
        eyebrow="مساحتك الأكاديمية"
        title={`أهلًا، ${auth.user?.full_name.split(' ')[0] ?? ''}`}
        description="كل إنجاز يقرّبك من فهم رحلتك. إليكِ صورة اليوم."
        action={
          <Link className="btn btn-secondary" to="/app/profile">
            ملفي الأكاديمي
            <ArrowLeft size={16} />
          </Link>
        }
      />
      <section className="welcome-banner">
        <div>
          <Badge tone="teal">خطتك الحالية</Badge>
          <h2>{major?.name_ar ?? 'جارٍ تحميل التخصص'}</h2>
          <p>
            الخطة {plan ? number(plan.plan_number) : '…'} <span>·</span> إجمالي ساعات الخطة:{' '}
            {number(plan?.total_credit_hours)}
          </p>
          <Link to="/app/curriculum">
            استكشفي مساقاتك
            <ArrowLeft size={17} />
          </Link>
        </div>
        <div className="banner-art" aria-hidden="true">
          <div className="art-orbit" />
          <GraduationCap size={75} />
          <span>
            <BookOpen size={19} />
          </span>
        </div>
      </section>
      <div className="stats-grid">
        <Stat
          label="ساعات منجزة معروفة"
          value={number(p.known_completed_credit_hours)}
          hint={
            p.completed_credit_summary.unknown_credit_course_count
              ? `${number(p.completed_credit_summary.unknown_credit_course_count)} مساق بساعات غير معروفة`
              : 'من المساقات التي أعلنتِ اجتيازها'
          }
          icon={<GraduationCap size={23} />}
        />
        <Stat
          label="مساقات منجزة"
          value={number(p.completed_course_count)}
          hint="إقرار شخصي، غير موثّق جامعيًا"
          icon={<CheckCheck size={23} />}
        />
        <Stat
          label="مساقات غير منجزة"
          value={number(p.remaining_course_count)}
          hint="تشمل الخيارات الاختيارية المتاحة"
          icon={<BookOpen size={23} />}
        />
        <Stat
          label="مساقات الخطة المتاحة"
          value={number(p.total_known_curriculum_courses)}
          hint="بحسب العضويات المسجلة حاليًا"
          icon={<Layers3 size={23} />}
        />
      </div>
      <div className="dashboard-columns">
        <section className="surface">
          <div className="section-heading">
            <div>
              <span className="section-kicker">خطوة بخطوة</span>
              <h2>آخر إنجازاتك</h2>
            </div>
            <Link to="/app/completed">
              عرض الكل
              <ArrowLeft size={15} />
            </Link>
          </div>
          {recent.length ? (
            recent.map((c) => (
              <Link
                className="recent-course"
                key={c.course_code}
                to={`/app/curriculum/${c.course_code}`}
              >
                <span className="course-mini-icon">
                  <CheckCircle2 size={22} />
                </span>
                <div>
                  <h3>{c.name_ar}</h3>
                  <small>
                    <bdi>{c.course_code}</bdi> · {number(c.credit_hours)} ساعة
                  </small>
                </div>
                <ArrowLeft size={17} />
              </Link>
            ))
          ) : (
            <Empty
              title="بداية جديدة، ومساحة لإنجازك"
              description="أضيفي أول مساق اجتزتِه لتبدئي متابعة تقدمك."
              action={
                <Link className="btn btn-secondary" to="/app/completed">
                  إضافة مساق منجز
                  <Plus size={16} />
                </Link>
              }
            />
          )}
        </section>
        <section className="surface">
          <div className="section-heading">
            <div>
              <span className="section-kicker">اختيارك التالي</span>
              <h2>اختصارات مفيدة</h2>
            </div>
            <Compass size={22} />
          </div>
          <Link className="quick-action" to="/app/curriculum">
            <BookOpen />
            <div>
              <strong>افهمي خطتك</strong>
              <small>ابحثي في المساقات ومتطلباتها</small>
            </div>
            <ArrowLeft size={17} />
          </Link>
          <Link className="quick-action" to="/app/completed">
            <CheckCheck />
            <div>
              <strong>حدّثي إنجازك</strong>
              <small>احتفظي بسجل المساقات المجتازة</small>
            </div>
            <ArrowLeft size={17} />
          </Link>
          <Link className="quick-action" to="/app/progress">
            <Layers3 />
            <div>
              <strong>راجعي تقدمك</strong>
              <small>ساعات معروفة وأهداف الاختياري</small>
            </div>
            <ArrowLeft size={17} />
          </Link>
        </section>
      </div>
      <EngagementDashboard />
      <ProductivityDashboard />
      <Completeness />
    </>
  );
}
