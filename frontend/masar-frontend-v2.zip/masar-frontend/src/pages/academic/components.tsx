import { ArrowLeft, BookOpen, CheckCircle2 } from 'lucide-react';
import { Link } from 'react-router-dom';
import type { Course, ElectiveGroup } from '../../api/types';
import { Badge, Notice, number, roleLabel } from '../../components/ui';

export function Completeness() {
  return (
    <Notice>
      <strong>صورة واضحة، ضمن البيانات المتاحة</strong>
      <p>
        هذه الأرقام تخص المساقات المسجلة في خطتك الحالية. بعض متطلبات الدرجة لم تُستكمل، لذا لا نعرض
        نسبة تخرج أو أهلية تخرج رسمية.
      </p>
    </Notice>
  );
}
export function GroupCard({ group }: { group: ElectiveGroup }) {
  const completed = group.known_credit_hours,
    target = group.required_credit_hours;
  return (
    <article className="elective-card">
      <div>
        <span className="section-kicker">مجموعة اختياري</span>
        <h3>{group.name_ar ?? 'مجموعة الاختياري'}</h3>
      </div>
      <div className="elective-numbers">
        <strong>
          {number(completed)} <small>/ {number(target)}</small>
        </strong>
        <span>ساعة معروفة / مطلوبة من المجموعة</span>
      </div>
      {typeof target === 'number' && target > 0 && typeof completed === 'number' && (
        <progress
          value={Math.min(completed, target)}
          max={target}
          aria-label="الساعات المنجزة من مجموعة الاختياري"
        />
      )}
      <p>المطلوب هو هدف المجموعة، وليس اجتياز جميع الخيارات.</p>
    </article>
  );
}
export function CourseCard({ course, completed }: { course: Course; completed: boolean | null }) {
  return (
    <article className="course-card">
      <div className="course-card-top">
        <span className="course-symbol">
          <BookOpen size={19} />
        </span>
        <Badge
          tone={
            course.requirement_type === 'UNVERIFIED'
              ? 'amber'
              : course.requirement_type === 'ELECTIVE'
                ? 'teal'
                : 'blue'
          }
        >
          {roleLabel(course.requirement_type)}
        </Badge>
      </div>
      <bdi className="course-code">{course.course_code}</bdi>
      <h3>{course.source_name_ar ?? course.name_ar}</h3>
      <div className="course-meta">
        <span>{number(course.credit_hours)} ساعة</span>
        <span>المستوى {number(course.level)}</span>
      </div>
      <footer>
        {completed === null ? (
          <span className="muted">جارٍ التحقق من الإنجاز</span>
        ) : completed ? (
          <span className="completed-label">
            <CheckCircle2 size={16} /> منجز بإقرارك
          </span>
        ) : (
          <span className="muted">لم يُعلن إنجازه</span>
        )}
        <Link to={`/app/curriculum/${course.course_code}`} aria-label={`تفاصيل ${course.name_ar}`}>
          التفاصيل
          <ArrowLeft size={15} />
        </Link>
      </footer>
    </article>
  );
}
