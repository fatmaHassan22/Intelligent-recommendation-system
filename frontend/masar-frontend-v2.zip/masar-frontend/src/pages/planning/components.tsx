import { BookOpen, CheckCheck, Layers3, Plus, Route, Sparkles } from 'lucide-react';
import type {
  AcademicTerm,
  Category,
  DraftCourse,
  DraftValidation,
  Recommendation,
} from '../../api/planning';
import { Badge, Button, Confirm, Stat, number, roleLabel } from '../../components/ui';

export const categoryLabels: Record<Category, string> = {
  SUITABLE: 'مناسب أكاديميًا',
  BLOCKED: 'غير مستوفٍ',
  UNVERIFIED: 'يحتاج تحققًا',
  NOT_OFFERED: 'مؤكد عدم الطرح',
};
export const offeringLabels = {
  NOT_RECORDED: 'الطرح الفعلي غير مسجل',
  UNVERIFIED: 'سجل الطرح غير موثق رسميًا',
  CONFIRMED_OFFERED: 'مؤكد الطرح',
  CONFIRMED_NOT_OFFERED: 'مؤكد عدم الطرح',
};
export function StudyOptions() {
  return (
    <>
      <option value="LIGHT">خفيف</option>
      <option value="BALANCED">متوازن</option>
      <option value="FAST_GRADUATION">تخرج أسرع</option>
    </>
  );
}
export function TermOptions({ terms }: { terms: AcademicTerm[] }) {
  return (
    <>
      <option value="">بدون فصل محدد</option>
      {terms.map((t) => (
        <option key={t.id} value={t.id}>
          {t.academic_year} · {t.semester_name_ar}
        </option>
      ))}
    </>
  );
}
export function Credits({ validation }: { validation: DraftValidation }) {
  const c = validation.credit_summary;
  return (
    <div className="stats-grid planning-stats">
      <Stat
        label="الساعات المعروفة"
        value={number(c.known_credit_hours)}
        hint={
          c.is_total_complete ? 'إجمالي الساعات مكتمل' : 'هذا الجزء المعروف فقط؛ الإجمالي غير مكتمل'
        }
        icon={<BookOpen />}
      />
      <Stat
        label="مساقات بساعات مجهولة"
        value={number(c.unknown_credit_course_count)}
        hint="لم تُحسب ساعاتها كصفر"
        icon={<Layers3 />}
      />
      <Stat
        label="السعة المتبقية"
        value={number(c.remaining_credit_capacity)}
        hint={
          c.exceeds_configured_max
            ? 'تجاوزتِ الحد المفضل'
            : `الحد المفضل: ${number(c.configured_max_credit_hours)} ساعة`
        }
        icon={<Route />}
      />
      <Stat
        label="حمل الدراسة المتحقق"
        value={number(validation.workload.total_score)}
        hint={
          validation.workload.unknown_course_count
            ? 'بيانات الصعوبة غير مكتملة؛ ليست ساعات معتمدة'
            : 'نقاط صعوبة متحققة منفصلة عن الساعات'
        }
        icon={<CheckCheck />}
      />
    </div>
  );
}
export function Evaluation({
  course,
}: {
  course: DraftCourse & { ranking?: Recommendation['ranking'] };
}) {
  return (
    <details className="evaluation-details">
      <summary>لماذا؟ المتطلبات وعوامل الترتيب</summary>
      <ul>
        {course.reasons.map((r) => (
          <li key={r.code}>{r.text_ar}</li>
        ))}
      </ul>
      {!!course.prerequisites.groups.length && (
        <div className="mini-prerequisites">
          <p>
            كل بند مطلوب (و)؛ داخل البند يكفي بديل واحد (أو). الاختيارات في المسودة ليست إنجازًا.
          </p>
          {course.prerequisites.groups.map((g) => (
            <div key={g.group_number}>
              <strong>البند {number(g.group_number)}</strong>
              <span>
                {g.courses.map((code, i) => (
                  <span key={code}>
                    {i > 0 ? ' أو ' : ''}
                    <bdi>{code}</bdi>
                  </span>
                ))}
              </span>
              <Badge
                tone={
                  g.satisfied &&
                  !course.prerequisites.is_unverified &&
                  !course.prerequisites.requires_academic_review
                    ? 'teal'
                    : 'amber'
                }
              >
                {course.prerequisites.is_unverified || course.prerequisites.requires_academic_review
                  ? 'غير متحقق'
                  : g.satisfied
                    ? 'مستوفى'
                    : 'غير مستوفى'}
              </Badge>
            </div>
          ))}
        </div>
      )}
      {course.category === 'SUITABLE' && course.ranking && (
        <div className="ranking-factors">
          <strong>نقاط الترتيب: {number(course.ranking.score)}</strong>
          {course.ranking.factors.length ? (
            <ul>
              {course.ranking.factors.map((f) => (
                <li key={f.code}>
                  {f.label_ar}: {number(f.points)} نقطة
                </li>
              ))}
            </ul>
          ) : (
            <p>لا توجد عوامل متحققة تميّز ترتيب هذا المساق؛ يُستخدم رمز المساق لكسر التعادل.</p>
          )}
        </div>
      )}
    </details>
  );
}
export function RecommendationCard({
  course,
  onAdd,
  busy,
  disabled,
  suggested = false,
}: {
  course: Recommendation;
  onAdd: () => void;
  busy: boolean;
  disabled: boolean;
  suggested?: boolean;
}) {
  return (
    <article className="course-card recommendation-card">
      <div className="course-card-top">
        <Badge
          tone={
            course.category === 'SUITABLE'
              ? 'teal'
              : course.category === 'BLOCKED'
                ? 'neutral'
                : 'amber'
          }
        >
          {categoryLabels[course.category]}
        </Badge>
        {course.rank !== null && <span className="rank-pill">#{number(course.rank)}</span>}
      </div>
      <bdi className="course-code">{course.course_code}</bdi>
      <h3>{course.name_ar}</h3>
      <div className="course-meta">
        <span>{number(course.credit_hours)} ساعة</span>
        <span>
          {roleLabel(course.requirement_type)}
          {!course.classification_verified && course.requirement_type !== 'UNVERIFIED'
            ? ' (غير متحقق)'
            : ''}
        </span>
      </div>
      <Badge tone={course.offering_status === 'CONFIRMED_OFFERED' ? 'teal' : 'amber'}>
        {offeringLabels[course.offering_status]}
      </Badge>
      {suggested && (
        <p className="suggestion-note">
          <Sparkles size={14} /> ضمن المجموعة المقترحة وفق نمط الدراسة
        </p>
      )}
      <p className="recommendation-reason">
        {course.reasons.find((r) =>
          [
            'COMPLETED',
            'SELECTED',
            'PREREQUISITES_UNVERIFIED',
            'PREREQUISITES_MISSING',
            'HOURS_UNKNOWN',
            'CREDIT_LIMIT',
            'METADATA_UNVERIFIED',
          ].includes(r.code),
        )?.text_ar ?? course.reasons[0]?.text_ar}
      </p>
      <Evaluation course={course} />
      <footer>
        <Button
          variant="secondary"
          busy={busy}
          disabled={disabled || course.already_completed || course.already_selected}
          onClick={onAdd}
          aria-label={`إضافة ${course.course_code} إلى المسودة`}
        >
          <Plus size={16} />
          {course.already_completed
            ? 'منجز'
            : course.already_selected
              ? 'في المسودة'
              : course.category === 'SUITABLE'
                ? 'إضافة للمسودة'
                : 'إضافة للمراجعة'}
        </Button>
      </footer>
    </article>
  );
}
export function AddWarning({
  course,
  busy,
  onConfirm,
  onClose,
}: {
  course: Recommendation;
  busy: boolean;
  onConfirm: () => void;
  onClose: () => void;
}) {
  return (
    <Confirm
      title="حفظ المساق للمراجعة؟"
      description={`${course.name_ar}: ${course.reasons
        .filter((r) => !['DIFFICULTY_UNKNOWN', 'CLASSIFICATION_UNVERIFIED'].includes(r.code))
        .map((r) => r.text_ar)
        .join(' ')} سيُحفظ في المسودة مع التحذيرات، ولن يُعتبر مستوفيًا للشروط.`}
      busy={busy}
      onConfirm={onConfirm}
      onClose={onClose}
    />
  );
}
