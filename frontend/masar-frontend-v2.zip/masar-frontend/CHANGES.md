# التغييرات على الواجهة الأمامية

- تنسيق كل الكود بـ Prettier (`npm run format`).
- تقسيم الملفات الكبيرة: `pages/Auth`، `pages/Planning`، `pages/Academic`، `engagement/Engagement`
  إلى ملفات لكل صفحة/مسؤولية، مع `index.ts` في كل مجلد. `Logo` انتقل إلى `components/Logo.tsx`.
- صفحة Landing (`pages/auth/Landing.tsx`) تجمع أقسام `pages/sections`. أُزيلت استيرادات الأقسام
  المعطّلة (Assistant, Tour, Stories) لأنها غير مستخدمة؛ أعيدي استيرادها عند تفعيلها.
- إصلاح خطأ نوع في `MobileMenu` (`inert` صارت `true`). حذف `components/Heading.jsx` المكرر
  وكتل الكود المعلّق في `Auth` و`Logo`. `Logo` واحد في `components/Logo.tsx`.
- القائمة الجانبية: إصلاح كلاس `nav-divider` وأيقونات غير مكررة، وإزالة علم `future`.
- استُبدلت `FuturePage` بصفحة `NotFoundPage` (404 حقيقية داخل `/app`).
- polling التفاعل من 15 إلى 60 ثانية. وإضافة `componentDidCatch` لـ ErrorBoundary.
- ملفات إعداد مضافة: `vite.config.ts`, `vitest.config.ts`, `index.html`, `.prettierrc`, `.gitignore`.
  إن كانت عندك نسخ خاصة منها فاحتفظ بنسخك.
